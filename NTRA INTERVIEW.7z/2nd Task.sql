--          ������ ��� ������� ��� �����
--         ��� ������� ����� �� �����
--          ��� ��� ������� ����� �� �����
--          ��� �������� ������
--         ��� ��� �������� ������
--          ��� ������� ������ ������
--          ���� ������� ������ ������
--          ����� ��� �������� ���� ���� ��� ��������
--          ���� 5 ������� ��������
---          ���� ������ ������� ��������


sel
MonthlySnapshot
,MAX(Total_Num_Subs) as Total_Num_Subs
,MAX(Total_Num_Wallets) as Total_Num_Wallets
,MAX(NewReg_Wallets_Growth_PerMonth) as NewReg_Wallets_Growth_PerMonth
,MAX(Total_TRXs_PerMonth) as Total_TRXs_PerMonth
,MAX(TRXs_Growth_PerMonth) as TRXs_Growth_PerMonth
,MAX(Total_Num_Active_Wallets_PerMonth) as Total_Num_Active_Wallets_PerMonth
,MAX(Active_Wallets_Rate_PerMonth) as Active_Wallets_Rate_PerMonth
,MAX(Average_TRXs_PerUser_PerMonth) as Average_TRXs_PerUser_PerMonth
,MAX(FirstMost_TRXs_Gov) as FirstMost_TRXs_Gov
,MAX(SecondMost_TRXs_Gov) as SecondMost_TRXs_Gov
,MAX(ThirdMost_TRXs_Gov) as ThirdMost_TRXs_Gov
,MAX(FourthMost_TRXs_Gov) as FourthMost_TRXs_Gov
,MAX(FifthMost_TRXs_Gov) as FifthMost_TRXs_Gov
,MAX(AgeTier_With_MostUsers) as AgeTier_With_MostUsers
from
(
sel
MonthlySnapshot
,Total_Num_Wallets as Total_Num_Subs
,Total_Num_NewReg_Wallets_PerMonth as Total_Num_Wallets
,Coalesce(NewReg_Wallets_Growth_PerMonth,0) as NewReg_Wallets_Growth_PerMonth
,Total_TRXs_PerMonth
,Coalesce(TRXs_Growth_PerMonth,0) as TRXs_Growth_PerMonth
,Total_Num_Active_Wallets_PerMonth
,Active_Wallets_Rate_PerMonth
,Average_TRXs_PerUser_PerMonth
,' ' as FirstMost_TRXs_Gov
,' ' as SecondMost_TRXs_Gov
,' ' as ThirdMost_TRXs_Gov
,' ' as FourthMost_TRXs_Gov
,' ' as FifthMost_TRXs_Gov
,' ' as AgeTier_With_MostUsers

from (
sel
_Month
,_Month||'-'||_Year as MonthlySnapshot
,Total_Num_Wallets
,Total_Num_NewReg_Wallets_PerMonth
,Total_Num_NewReg_Wallets_PerMonth - LAG(Total_Num_NewReg_Wallets_PerMonth) OVER (ORDER BY _Month ASC) AS NewReg_Wallets_Growth_PerMonth
,Total_TRXs_PerMonth
,Total_TRXs_PerMonth - LAG(Total_TRXs_PerMonth) OVER (ORDER BY _Month ASC) AS TRXs_Growth_PerMonth
,Total_Num_Active_Wallets_PerMonth
,(Total_Num_Active_Wallets_PerMonth/Total_Num_Wallets) * 100 as Active_Wallets_Rate_PerMonth
,Total_TRXs_PerMonth/Total_Num_Wallets as Average_TRXs_PerUser_PerMonth
from(
sel
_Month
,_Month||'-'||_Year as MonthlySnapshot
,SUM(Total_Num_Wallets) as Total_Num_Wallets
,Sum(Total_Num_NewReg_Wallets_PerMonth) as Total_Num_NewReg_Wallets_PerMonth
,Sum(Total_Num_Wallets) as Total_Num_Wallets
,Sum(Total_TRXs_PerMonth) as Total_TRXs_PerMonth
,Sum(Total_Num_Active_Wallets_PerMonth) as Total_Num_Active_Wallets_PerMonth

from DevDB.Agg_Wallet_PerOperator_Monthly  
where _Year = 2020
group by 1,2
)Core
)fin

union all

sel
MonthlySnapshot
,0 as Total_Num_Subs
,0 as Total_Num_Wallets
,0 as NewReg_Wallets_Growth_PerMonth
,0 as Total_TRXs_PerMonth
,0 as TRXs_Growth_PerMonth
,0 as Total_Num_Active_Wallets_PerMonth
,0 as Active_Wallets_Rate_PerMonth
,0 as Average_TRXs_PerUser_PerMonth
,FirstMost_TRXs_Gov
,SecondMost_TRXs_Gov
,ThirdMost_TRXs_Gov
,FourthMost_TRXs_Gov
,FifthMost_TRXs_Gov
,' ' as AgeTier_With_MostUsers
from(
sel
MonthlySnapshot
,MAX(Case when rnk = 1 then Gov_Name end) as FirstMost_TRXs_Gov
,MAX(Case when rnk = 2 then Gov_Name end) as SecondMost_TRXs_Gov
,MAX(Case when rnk = 3 then Gov_Name end) as ThirdMost_TRXs_Gov
,MAX(Case when rnk = 4 then Gov_Name end) as FourthMost_TRXs_Gov
,MAX(Case when rnk = 5 then Gov_Name end) as FifthMost_TRXs_Gov
(
sel
_Month
,_Month||'-'||_Year as MonthlySnapshot
,govLKP.Gov_Name
,Total_Num_TRXs
,RANK() OVER (partition by _Month order by Total_Num_TRXs desc) as rnk
from DevDB.Agg_Wallet_PerGov_Monthly gov
Left join DevDB.Gov_LKP govLKP on govLKP.gov_id =gov.gov_id 
where _Year = 2020
)Core
where rnk between 1 and 5
group by 1
)fin

union all

sel
MonthlySnapshot
,0 as Total_Num_Subs
,0 as Total_Num_Wallets
,0 as NewReg_Wallets_Growth_PerMonth
,0 as Total_TRXs_PerMonth
,0 as TRXs_Growth_PerMonth
,0 as Total_Num_Active_Wallets_PerMonth
,0 as Active_Wallets_Rate_PerMonth
,0 as Average_TRXs_PerUser_PerMonth
,' ' as FirstMost_TRXs_Gov
,' ' as SecondMost_TRXs_Gov
,' ' as ThirdMost_TRXs_Gov
,' ' as FourthMost_TRXs_Gov
,' ' as FifthMost_TRXs_Gov
,AgeTier as AgeTier_With_MostUsers
from(
sel 
_Month
,_Month||'-'||_Year as MonthlySnapshot
,AgeTier
,Total_Num_Subs
from DevDB.Agg_Wallet_Subs_AgeTiers 
where _Year = 2020
qualify ROW_NUMBER() OVER (partition by _month order by Total_Num_Subs desc) = 1 
)core
)FinReport

group by 1